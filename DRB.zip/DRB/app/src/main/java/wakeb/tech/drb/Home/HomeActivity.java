package wakeb.tech.drb.Home;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import wakeb.tech.drb.R;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}
