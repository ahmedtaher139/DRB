package wakeb.tech.drb.Base;

import android.content.res.Configuration;


import androidx.multidex.MultiDexApplication;

import com.franmontiel.localechanger.LocaleChanger;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import wakeb.tech.drb.data.DataManager;
import wakeb.tech.drb.data.SharedPrefsHelper;

/**
 * Created by A.taher on 10/17/2018.
 */

public class MainApplication extends MultiDexApplication {


    public static final List<Locale> SUPPORTED_LOCALES =
            Arrays.asList(
                    new Locale("en", "US"),
                    new Locale("ar", "EG"));

    DataManager dataManager;
    public DataManager getDataManager() {
        return dataManager;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        LocaleChanger.initialize(getApplicationContext(), SUPPORTED_LOCALES);
        SharedPrefsHelper sharedPrefsHelper = new SharedPrefsHelper(getApplicationContext());
        dataManager = new DataManager(sharedPrefsHelper);


    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        LocaleChanger.onConfigurationChanged();
    }



}
