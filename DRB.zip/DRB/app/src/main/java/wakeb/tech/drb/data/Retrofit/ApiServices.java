package wakeb.tech.drb.data.Retrofit;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import io.reactivex.Observable;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;



public interface ApiServices {


    public String BaseURL = "http://promo-sys.com/healthy/";


    @POST("notification")
    @FormUrlEncoded
    Observable<String> notification(@FieldMap Map<String, String> qStringMap);


}
