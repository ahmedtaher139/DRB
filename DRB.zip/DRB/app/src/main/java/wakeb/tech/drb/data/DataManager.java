package wakeb.tech.drb.data;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by A.taher on 10/15/2018.
 */

public class DataManager {


    SharedPrefsHelper mSharedPrefsHelper;
    public DataManager(SharedPrefsHelper sharedPrefsHelper) {
        mSharedPrefsHelper = sharedPrefsHelper;
    }

    public void clear() {
        mSharedPrefsHelper.clear();
    }

    public void saveLang(String name) {
        mSharedPrefsHelper.putLang(name);
    }
    public String getLang() {
        return mSharedPrefsHelper.getLang();
    }

    public void saveLangStatus(Boolean status) {
        mSharedPrefsHelper.putLangStatus(status);
    }
    public boolean getLangStatus() {
        return mSharedPrefsHelper.getLangStatus();
    }

    public void saveWelcomeStatus(Boolean Welcome) {
        mSharedPrefsHelper.putWelcomeStatus(Welcome);
    }
    public boolean getWelcomeStatus() {
        return mSharedPrefsHelper.getWelcomeStatus();
    }


    public void saveName(String name) {
        mSharedPrefsHelper.putName(name);
    }
    public String getName() {
        return mSharedPrefsHelper.getName();
    }

    public void saveImage(String image) {
        mSharedPrefsHelper.putImage(image);
    }
    public String getImage() {
        return mSharedPrefsHelper.getImage();
    }

    public void saveNumber(String Number) {
        mSharedPrefsHelper.putNumber(Number);
    }
    public String getNumber() {
        return mSharedPrefsHelper.getNumber();
    }

    public void saveID(String ID) {
        mSharedPrefsHelper.putID(ID);
    }
    public String getID() {
        return mSharedPrefsHelper.getID();
    }

    public void setLoggedIn() {
        mSharedPrefsHelper.setLoggedInMode(true);
    }
    public Boolean getLoggedInMode() {
        return mSharedPrefsHelper.getLoggedInMode();
    }





}


