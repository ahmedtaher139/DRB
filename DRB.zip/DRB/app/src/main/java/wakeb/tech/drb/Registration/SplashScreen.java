package wakeb.tech.drb.Registration;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import wakeb.tech.drb.Base.BaseActivity;
import wakeb.tech.drb.R;

public class SplashScreen extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sleep3 ();
    }


    @Override
    protected void setViewListeners() {

    }

    @Override
    protected void setViewReferences() {

    }

    @Override
    protected boolean isValidData() {
        return false;
    }


    void sleep3 ()
    {
      Thread  logoTimer = new Thread() {
            public void run() {
                try {
                    sleep(3000);
                } catch (InterruptedException e) {
                    Log.d("Exception", "Exception" + e);
                } finally {

startActivity(new Intent(SplashScreen.this , SelectLanguage.class));

                }

            }
        };


        logoTimer.start();
    }
}
